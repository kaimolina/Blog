class Author < ActiveRecord::Base
  has_many :articles
	validates_presence_of [:first_name, :last_name], :message => "First Name and Last Name required."
end
