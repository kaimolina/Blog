require 'test_helper'

class ArticleTest < ActiveSupport::TestCase
  
  setup do
	@article = Comment.create(:body => "ecc", :email =>"kaimolina2@gmail.com")
	@article_without_title = Comment.new(:body =>"exist code camper")
	@article_without_body = Comment.new(:title =>"kaimolina@gmail.com")
	end

  # Replace this with your real tests.
	teardown do
  end
  
	test "Should belong to Author" do
		assert_equal true, @article.respond_to?(:author)
	end
  
	test "Should have many comments" do
		assert_equal Array, @article.comments.class
	end
	
  test "Should validate the presence of body" do
		assert_equal false, @article_without_body.save
	end	
  
  test "Should validate the presence of email" do
		assert_equal false, @article_without_title.save
	end

  # Replace this with your real tests.
  test "the truth" do
    assert true
  end
end
